Mon code presente mon cv en html.

J'ai fait en sorte de suivre la rgaa cepandant dans les validateurs cela me renvoi des 'warning' comme quoi ce n'est pas necessaire.

Il y a 2 nav, une qui est dans le header permet de ce deplacer directement dans une section du site.
Et l'autre dans le footer permet d'avoir une liste de mes reseaux sociaux.

J'ai mis un main comme il est conventionner
un h1
un lien pour telecharger un VIRUS... non seulement mon pdf ^^

Il est Separer par 5 section : 
	A propos
	Experiences
	Competences
	Formations
	Contactez moi

Elle comporte un h2, h3 et un p et pour d'autre une liste
en fin de main j'ai fait un formluaire qui conentient des label pour chaque input, un text area pour envoyer un message et le bouton pour envoyer le formulaure qui pour le moment est seulement en GET mais il n'y pas de serveur pour receptionner.