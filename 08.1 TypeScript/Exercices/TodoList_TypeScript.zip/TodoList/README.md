TodoList

# Installation

1. Installer les dependences

    ```bash
    npm i
    ```

2. Lancer le serveur JSON

    ```bash
    npm start
    ```

## Compilation

1. Compilation dans le dossier prod

    ```bash
    tsc
    ```
### Execute la todo list

1. Ouvrir `index.html` avec `Live Server`.

#### PLUS

1. Ajout de la fonction deleteTask(Type: Task) qui permet de supprimer dans la base de donnee Json les taches apres l'appuis du bouton Supprimer.