import TodoList from "./src/components/TodoList.js";

// Création d'une todoList
const todoList = new TodoList();
