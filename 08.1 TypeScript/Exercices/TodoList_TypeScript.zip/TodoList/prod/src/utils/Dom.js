export default class Dom {
    /**
     * Crée un élément du dom, lui ajoute du texte, le place comme dernier
     * enfant de parent et ajoute un attribut en utilisant le paramètre attributes
     * @param {T extends MarkupName} markupName
     * @param {String} text
     * @param {HTMLElement} parent
     * @param {Record<string, any>} attributes
     * @returns {HTMLElementTagNameMap[T]} Peut être HTMLElement ou HTMLInputElement ou autre (voir HTMLElementTagNameMap)
     */
    createMarkup(markupName, text, parent, attributes = {}) {
        const markup = document.createElement(markupName);
        markup.textContent = text;
        parent.appendChild(markup);
        for (let key in attributes) {
            markup.setAttribute(key, attributes[key]);
        }
        return markup;
    }
}
