export const renderError = (message) => {
    window.alert(message);
};
