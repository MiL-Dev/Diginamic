import Dom from "../utils/Dom.js";
import FetchData from "../services/FetchData.js";
export default class Task extends Dom {
  public id: number | string;
  public name: string;
  public done: boolean;
  private parent: HTMLElement;
  private domElts: Record<string, HTMLElement>;
  /**
   * Constructor
   * @param {number | string} id
   * @param {string} name
   * @param {boolean} done
   * @param {HTMLElement} parent
   */
  constructor(
    id: number | string,
    name: string,
    done: boolean,
    parent: HTMLElement
  ) {
    super();
    this.id = id;
    this.name = name;
    this.done = done;
    this.parent = parent;

    // Affichage et récupération des références vers les éléments du DOM constitutifs de la tâches
    this.domElts = this.render();

    // Gestion des événements
    this.manageEvents();

    console.log(`task créée : `, this);
  }

  /**
   * Add event to validate and delete buttons when click
   */
  manageEvents() {
    this.domElts.buttonDeleteElt.addEventListener("click", () => {
      console.log(`bouton delete cliqué`);
      this.domElts.articleElt.remove();
      FetchData.deleteTask(this);
    });
    // Gestion du clic sur le bouton Valider / Invalider
    this.domElts.buttonValidateElt.addEventListener("click", () => {
      console.log(`bouton Valider/Invalider cliqué`);

      // Changement local
      this.done = !this.done;
      this.domElts.h2Elt.classList.toggle("done");
      if (
        this.domElts.h2Elt.classList.contains("done") &&
        this.domElts.articleElt
      )
        this.parent.appendChild(this.domElts.articleElt);
      else if (this.domElts.articleElt) {
        this.parent.prepend(this.domElts.articleElt);
      }
      // Gestion du label
      if (this.domElts.buttonValidateElt) {
        this.domElts.buttonValidateElt.innerText = this.done
          ? "Invalider"
          : "Valider";
      }

      // Appel du service
      FetchData.patchTask(this.id, { done: this.done });
    });
  }

  /**
   * Render this Task in its parent
   * @returns {Object} DOM Elements rendered
   */
  render() : Record<string, HTMLElement> {
    // gestion de la class pour savoir si la tâche est faite ou pas
    const attributeClass = this.done ? { class: "done" } : {};
    // création des éléments du DOM constitutifs de la tâche
    const articleElt = this.createMarkup("article", "", this.parent, {"class" : "task"});
    const h2Elt = this.createMarkup(
      "h2",
      this.name,
      articleElt,
      attributeClass
    );
    const buttonsDiv = this.createMarkup("div", "", articleElt);
    const buttonValidateElt = this.createMarkup(
      "button",
      "Valider",
      buttonsDiv
    );
    const buttonDeleteElt = this.createMarkup(
      "button",
      "Supprimer",
      buttonsDiv
    );
    return {
      articleElt,
      h2Elt,
      buttonDeleteElt,
      buttonValidateElt,
    };
  }
}
