import Dom from "../utils/Dom.js";
import Task from "./Task.js";
import FetchData from "../services/FetchData.js";

interface TodoListDomElements {
  form: HTMLElement;
  input: HTMLInputElement;
  sectionListTasks: HTMLElement;
}

export default class TodoList extends Dom {
  private rootDom: HTMLElement;
  private domElts: TodoListDomElements;
  /**
   * Constructor
   */
  constructor() {
    super();
    // Référence à l'élément du DOM existant qui a pour id "root"
    this.rootDom = document.getElementById("root")!;

    // Création des éléments du DOM
    this.domElts = this.render();

    // Gestion des événements
    this.manageEvents();

    // Import des tâches
    (async () => {
      const tasks = await FetchData.loadTasks();
      console.log(`taches dans le constructeur de TodoList`, tasks);
      console.log(`this`, this);
      this.renderTasks(tasks);
    })();
  }

  /**
   * Add event to form when submit to create a Task
   */
  manageEvents(): void {
    this.domElts.form.addEventListener("submit", (event) => {
      console.log(`Dans submit addEventListener`);
      // Supprimer l'appel de la requête http via l'action du formulaire avec la méthode GET
      event.preventDefault();

      // Récupération des données envoyées par le formulaire
      const taskName = this.domElts.input?.value;
      if (taskName) {
        // Création d'une tâche
        const new_task = {
          name: taskName,
          done: false,
        };
        new Task(
          Math.floor(Math.random() * 1000),
          new_task.name,
          new_task.done,
          this.domElts.sectionListTasks
        );
        this.domElts.input.value = "";
        // Ajout de la tâche sur le serveur via FechData.addTask(new_task)
        FetchData.addTask(new_task);
      }
    });
  }

  /**
   * Render the TodoList in DOM
   * @returns {TodoListDomElements} DOM elements rendered
   */
  render(): TodoListDomElements {
    // Création du formulaire
    const form = this.createMarkup("form", "", this.rootDom);
    const label = this.createMarkup("label", "Tâche : ", form, { for: "task" });
    const input = this.createMarkup("input", "", form, {
      id: "task",
      type: "text",
    });
    const buttonSubmit = this.createMarkup("button", "Ajouter la tâche", form, {
      id: "task",
      type: "submit",
    });
    // Création de l'élément section qui comprend toutes les tâches
    const sectionListTasks = this.createMarkup("section", "", this.rootDom, {
      class: "flex-col",
    });

    return {
      form,
      input,
      sectionListTasks,
    };
  }

  /**
   * Sort tasks and render them in this TodoList.
   * @param {Task[]} tasks
   */
  renderTasks(tasks: Task[]) {
    tasks
      .sort((a, b) => {
        return Number(a.done) - Number(b.done);
      })
      .forEach((task) => {
        new Task(task.id, task.name, task.done, this.domElts.sectionListTasks);
      });
  }
}
