import Task from "../components/Task.js";
import TodoList from "../components/TodoList.js";
import { renderError } from "../utils/Error.js";

export default class FetchData {
  static url = "http://localhost:3000/tasks";

  /**
   * Va chercher les tâches sur le serveur json-server en exécutant une requête http avec le verbe GET
   * @returns Promise<Task[]>
   */
  static async loadTasks() {
    return fetch(FetchData.url)
      .then((response) => {
        if (response.status != 200) {
          throw new Error("Pb dans loadTasks");
        } else return response.json();
      })
      .then((tasks) => {
        console.log(`tasks :`, tasks);
        return tasks;
      })
      .catch((error) => {
        console.log(`Erreur attrapée` + error);
        renderError("Erreur lors de la récupération des tâches.");
      });
  }
  /**
   * Ajoute une tâche sur le serveur json-server en exécutant une requête http avec le verbe POST
   * @returns Promise<Task>
   */
  static async addTask(new_task: Pick<Task, "name" | "done">) {
    return fetch(FetchData.url, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(new_task),
    })
      .then((response) => {
        console.log(`status dans le post`, response.status);
        if (response.status != 201) {
          throw new Error("Pb dans addTask");
        } else return response.json();
      })
      .then((task) => {
        console.log(`task retournée après un post :`, task);
        return task;
      })
      .catch((error) => {
        console.log(`Erreur attrapée dans addTask` + error);
        renderError("Erreur lors de la création, cette tâche ne sera pas enregistrée.");
      });
  }
  /**
   * Call server on id with task to update it in server side
   * @param {number | string} id 
   * @param {Task} updatedTask 
   * @returns {Task} task returned by server
   */
  static async patchTask(id: number | string, updatedTask: Partial<Task>) {
    return fetch(`${FetchData.url}/${id}`, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      method: "PATCH",
      body: JSON.stringify(updatedTask),
    })
      .then((response) => {
        if (response.status != 200) {
          throw new Error("Pb dans patchTask");
        } else return response.json();
      })
      .then((task) => {
        console.log(`Task updated:`, task);
        return task;
      })
      .catch((error) => {
        console.log(`Error caught in patchTask: ` + error);
        renderError("Erreur lors de la modification de la tâche, les changements ne sont pas enregistrés.");
      });
  }
  /**
   * Delete task on the server db json
   * @param {Task}
   */
  static async deleteTask(task:Task){
    return fetch(`${FetchData.url}/${task.id}`, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      method: "DELETE",
      body: JSON.stringify(task)
    })
      .then(response => {
        if (response.status != 200) {
          throw new Error("Pb dans patchTask")
        } else return response.json();
      })
      .then(task => {
        console.log(`Task updated:`, task);
        return task;
      })
      .catch(error => {
        console.log(`Error caught in patchTask: ` + error);
      })
  }

}
