type MarkupName = keyof HTMLElementTagNameMap;

export default class Dom {
  /**
   * Crée un élément du dom, lui ajoute du texte, le place comme dernier
   * enfant de parent et ajoute un attribut en utilisant le paramètre attributes
   * @param {T extends MarkupName} markupName
   * @param {String} text
   * @param {HTMLElement} parent
   * @param {Record<string, any>} attributes
   * @returns {HTMLElementTagNameMap[T]} Peut être HTMLElement ou HTMLInputElement ou autre (voir HTMLElementTagNameMap)
   */
  createMarkup<T extends MarkupName>(
    markupName: T,
    text: string,
    parent: HTMLElement,
    attributes: Record<string, any> = {}
  ): HTMLElementTagNameMap[T] {
    const markup = document.createElement<T>(markupName);
    markup.textContent = text;
    parent.appendChild(markup);
    for (let key in attributes) {
      markup.setAttribute(key, attributes[key]);
    }
    return markup;
  }
}
