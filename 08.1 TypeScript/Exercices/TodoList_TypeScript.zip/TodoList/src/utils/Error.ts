export const renderError = (message: string): void => {
  window.alert(message);
};
